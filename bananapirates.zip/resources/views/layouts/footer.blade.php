{{--  footer  --}}
<div class="col-lg-12 footer">
    {{-- medsos --}}
    <div class="flex">
        <div class="col-lg-3">
            <img src="">@bananapirates
        </div>
        <div class="col-lg-3">
            <img src="">bananapirates
        </div>
        <div class="col-lg-3">
            <img src="">BananapPirates
        </div>
        <div class="col-lg-3">
            <img src="">bananapirates
        </div>
    </div>
    {{-- partnership --}}
    <div class="partnership-container">
        <img src="">
    </div>
    <p style="padding: 50px;" class="center">Copyright (c) 2018 Web Bananapirates.id</p>
</div>