<!DOCTYPE html>
<html>
<?php echo $__env->make('layouts.admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        blog
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">blog</li>
      </ol>
    </section>
 
    <section class="content">
        <div class="row">
                <div class="col-lg-12 margin-tb">
                    <div class="pull-left">
                        <h2>blog list</h2>
                    </div>
                    <div class="pull-right">
                        <a class="btn btn-success" href="<?php echo e(route('blog.create')); ?>"> Create New blog</a>
                        
                    </div>
                </div>
            </div>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>

            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>title</th>
                    <th>picture</th>
                    <th>content</th>
                    <th width="280px">Action</th>
                </tr>
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($blog->title); ?></td>
                <td><img src="<?php echo e($blog -> pictures); ?>" style="height:50px;width:50px;text-align:center"></td>
                <td><?php echo e($blog->content); ?></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('blog.show',$blog->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('blog.edit',$blog->id)); ?>">Edit</a>
                    <?php echo Form::open(['method' => 'DELETE','route' => ['blog.destroy', $blog->id],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            
            <?php echo $blogs->links(); ?>

    </section>
</div>

<?php echo $__env->make('layouts.admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
</body>
</html>
