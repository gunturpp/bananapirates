<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Title:</strong>
            <?php echo Form::text('title', null, array('placeholder' => 'Title','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Content :</strong>
            <?php echo Form::textarea('content', null, array('placeholder' => 'Fill content...(max 10000 character)','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group <?php echo $errors->has('pictures') ? 'has-error' : ''; ?>">
            <strong>Pictures :</strong>
            <?php echo Form::file('pictures'); ?>

            <?php echo Form::label('pictures', 'Must be in format ( jpg,jpeg,png )*'); ?>

        </div>
    </div>

    <!-- <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Foto:</strong>
            <?php echo Form::file('pictures', null); ?>

        </div>
    </div> -->



    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>