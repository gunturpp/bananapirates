<?php $__env->startSection('content'); ?>

<div>
    <div class="profile-container">
        <img class="meet-banner" src="<?php echo e(asset('../images/blogs/banner.jpg')); ?>">
        
        <div class="container meet-mg">
            <h1 class="meet-title"><b>MEET OUR TEAM</b></h1>
                <div class="team-content">
                    <img class="team-img" src="<?php echo e(asset('images/blogs/batik.jpg')); ?>">
                    <p class="justify">
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum Lorepsum 
                    </p>
                </div>
            </div>
            <div class="flex container">
                <div class="wd25">
                    <img class="persons-img" src="<?php echo e(asset('../images/blogs/banner.jpg')); ?>">
                </div>
                <div class="wd25">
                    <img class="persons-img" src="<?php echo e(asset('../images/blogs/banner.jpg')); ?>">
                </div>
                <div class="wd25">
                    <img class="persons-img" src="<?php echo e(asset('../images/blogs/banner.jpg')); ?>">
                </div>
                <div class="wd25">
                    <img class="persons-img" src="<?php echo e(asset('../images/blogs/banner.jpg')); ?>">
                </div>
            </div>
            <div class="flex container">
                <div class="wd25">
                    <img class="persons-img" src="<?php echo e(asset('../images/blogs/banner.jpg')); ?>">
                </div>
                <div class="wd25">
                    <img class="persons-img" src="<?php echo e(asset('../images/blogs/banner.jpg')); ?>">
                </div>
                <div class="wd25">
                    <img class="persons-img" src="<?php echo e(asset('../images/blogs/banner.jpg')); ?>">
                </div>
                <div class="wd25">
                    <img class="persons-img" src="<?php echo e(asset('../images/blogs/banner.jpg')); ?>">
                </div>
            </div>
    </div>
</div>


<?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>