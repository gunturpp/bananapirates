<?php $__env->startSection('content'); ?>

<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="pull-right" style="margin-top:15px;">
                        <a class="btn btn-primary" href="<?php echo e(route('eventproject.index')); ?>">Back</a>
                    </div>
                    <div class="col-lg-12">
                        <center><h1 class="page-header">Event & Project Data Detail</h1></center>
                    </div>
            </div>
            
            
        </div>
    </div>

    <div style="width: 80%; margin: auto;">
      	<table class="table centered">

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Title :</strong>
                        <?php echo e($event_projects->title); ?>

                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Title :</strong>
                        <a href="https://<?php echo e($event_projects->link_registration); ?>"><?php echo e($event_projects->link_registration); ?></a>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Content :</strong>
                        <?php echo e($event_projects->content); ?>

                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Picture :</strong>
                        <img src="<?php echo e(asset($event_projects->pictures)); ?>" style="text-align:center">
                    </div>
                </div>

            </div>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>