<?php $__env->startSection('content'); ?>
<div class="gallery-container">
    <div class="flex">
        <div class="col-lg-6">
            <h1>GALERI FOTO & VIDEO</h1>
        </div>
        <div class="col-lg-6">
            <img class="logo-banana logo-banana-store" src="<?php echo e(asset('../images/icon/logo-banana.png')); ?>">
        </div>
    </div>
    <div class="flex">
        <div class="col-lg-3">
            <div class="gallery-category-btn">
                <a class="gallery-category" href="#">PULAU PISANG</a>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="gallery-category-btn">
                <a class="gallery-category" href="#">PULAU PISANG</a>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="gallery-category-btn">
                <a class="gallery-category" href="#">PULAU PISANG</a>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="gallery-category-btn">
                <a class="gallery-category" href="#">PULAU PISANG</a>
            </div>
        </div>
    </div>
    
    <div class="gallery-content">
    </div>
</div>
    

<?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>